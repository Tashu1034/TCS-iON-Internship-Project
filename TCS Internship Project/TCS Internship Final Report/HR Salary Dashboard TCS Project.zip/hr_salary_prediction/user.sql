CREATE DATABASE IF NOT EXISTS user_system DEFAULT CHARACTER SET utf8 COLLATE utf8_general_ci;
USE user_system;

CREATE TABLE IF NOT EXISTS user (
	id int(11) NOT NULL AUTO_INCREMENT,
  	username varchar(100) NOT NULL,
        email varchar(100) NOT NULL,
  	password varchar(50) NOT NULL,
    PRIMARY KEY (id)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

INSERT INTO user VALUES (1, 'Tashfeen', 'muneebtashfeen7@gmail.com', 'tashfeen');