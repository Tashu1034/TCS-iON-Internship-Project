from flask import Flask, render_template, request, redirect, url_for, session,flash
from flask import *
from flask_mysqldb import MySQL
import MySQLdb.cursors
import re
from openpyxl import load_workbook
import pandas as pd
import numpy as np
import joblib

app = Flask(__name__)

app.secret_key = "super secret key"
 
app.config['MYSQL_HOST'] = 'localhost'
app.config['MYSQL_PORT'] = 3306
app.config['MYSQL_USER'] = 'root'
app.config['MYSQL_PASSWORD'] = 'tashfeen'
app.config['MYSQL_DB'] = 'user_system'
 
mysql = MySQL(app)

app.config["SESSION_PERMANENT"] = False

@app.route("/")
def welcome():
    return render_template("welcome.html")

@app.route('/login', methods=['GET', 'POST'])
def login():
    msg = ''
    if request.method == 'POST' and 'username' in request.form and 'password' in request.form:
        # Create variables for easy access
        username = request.form['username']
        password = request.form['password']
        cursor = mysql.connection.cursor(MySQLdb.cursors.DictCursor)
        cursor.execute('SELECT * FROM user WHERE username = %s AND password = %s', (username, password,))
        # Fetch one record and return result
        account = cursor.fetchone()
        if account:
            # Create session data, we can access this data in other routes
            session['loggedin'] = True
            # session['id'] = account['id']
            session['username'] = account['username']
            # session['username'] = account[1]
            return render_template('home2.html',username = session["username"])
        else:
            # Account doesnt exist or username/password incorrect
            msg = 'Incorrect username/password!'
            return render_template('login.html', msg=msg)
        
    return render_template('login.html', msg='')


@app.route('/register', methods=['GET', 'POST'])
def register():
    msg = ''
    # Check if "username", "password" and "email" POST requests exist (user submitted form)
    if request.method == 'POST' and 'username' in request.form and 'email' in request.form and 'password' in request.form:
        # Create variables for easy access
        username = request.form['username']
        email = request.form['email']
        password = request.form['password']

        # Check if account exists using MySQL
        cursor = mysql.connection.cursor(MySQLdb.cursors.DictCursor)
        cursor.execute('SELECT * FROM user WHERE username = %s', (username,))
        account = cursor.fetchone()
        # If account exists show error and validation checks
        if account:
            msg = 'Account already exists!'
        elif not re.match(r'[^@]+@[^@]+\.[^@]+', email):
            msg = 'Invalid email address!'
        elif not re.match(r'[A-Za-z0-9]+', username):
            msg = 'Username must contain only characters and numbers!'
        elif not username or not password or not email:
            msg = 'Please fill out the form!'
        else:
            # Account doesnt exists and the form data is valid, now insert new account into accounts table
            cursor.execute('INSERT INTO user VALUES (NULL, %s, %s, %s)', (username, password, email,))
            mysql.connection.commit()
            msg = 'You have successfully registered!'
    elif request.method == 'POST':
        # Form is empty... (no POST data)
        msg = 'Please fill out the form!'
    # Show registration form with message (if any)
    return render_template('register.html', msg=msg)

@app.route('/home')
def home():
    return render_template('home.html')

@app.route('/home2')
def home2():
    msg = "Successfully Logged In!"
    return render_template('home2.html',msg = msg)

@app.route('/preview')
def preview():
    hr = load_workbook(r"C:\Users\DELL\Downloads\hr_salary_prediction\hr.xlsx")
    sheet = hr.active
    return render_template("preview.html", sheet=sheet)

@app.route('/prediction', methods=['GET', 'POST'])
def prediction():
    if request.method == "POST":
        output = 0
        age = float(request.form['age'])
        years_of_experience = float(request.form['years_of_experience'])

        X = np.array([[age,years_of_experience]])

        try:
            scaler_path = r'C:\Users\DELL\Downloads\hr_salary_prediction\model\sc.sav'

            sc = joblib.load(scaler_path)

            X_std = sc.transform(X)

            model_path = r'C:\Users\DELL\Downloads\hr_salary_prediction\model\linear_regression_model.sav'

            model = joblib.load(model_path)

            Y_pred = model.predict(X_std)
            
            return render_template("prediction.html", Prediction="Predicted Salary : $"+"%.2f" % float(Y_pred))       
        except:
            print("Error")
    return render_template('prediction.html')
    

@app.route('/performance')
def performance():
    return render_template('performance.html')

@app.route('/logout')
def logout():
    session.pop('loggedin', None)
    session.pop('id', None)
    session.pop('username', None)
    return redirect(url_for('login'))

app.run(debug=True)